import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { Line } from 'react-chartjs-2';
import 'chart.js/auto';
import { Activity, Play, Square, Server, FileText, XCircle } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const socket = io(API);
const MAX_POINTS = 31; // rolling window shown on the live chart

// POST helper: throws an Error carrying the backend's message when the request is rejected
async function post(path, body) {
  const res = await fetch(`${API}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body ?? {})
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

const keep = (arr, v) => [...arr, v].slice(-MAX_POINTS);
const emptySeries = { labels: [], avg: [], p95: [], errors: [] };

const FINISH_REASONS = {
  'max-duration': 'Test stopped automatically: the 5-minute safety limit was reached.',
  'worker-error': 'Test stopped: the load worker crashed.',
  'worker-exit': 'Test stopped: the load worker exited unexpectedly.'
};

function Stat({ label, value, unit, color }) {
  return (
    <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
      <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">{label}</p>
      <p className={`text-2xl font-mono font-bold ${color}`}>
        {value}{unit && <span className="text-sm text-slate-500 ml-1">{unit}</span>}
      </p>
    </div>
  );
}

export default function App() {
  const [targetUrl, setTargetUrl] = useState('http://localhost:4000/api/ping');
  const [virtualUsers, setVirtualUsers] = useState(50);
  const [chaosLatency, setChaosLatency] = useState(0);

  const [isRunning, setIsRunning] = useState(false);
  const [connected, setConnected] = useState(socket.connected);
  const [error, setError] = useState('');
  const [summaryData, setSummaryData] = useState(null);
  const [live, setLive] = useState(null);
  const [series, setSeries] = useState(emptySeries);

  // Live telemetry + connection state from the backend
  useEffect(() => {
    const onConnect = () => setConnected(true);
    const onDisconnect = () => setConnected(false);
    const onStatus = (s) => setIsRunning(!!s.running); // restores state after a browser refresh
    const onMetrics = (d) => {
      setLive(d);
      setSeries((prev) => ({
        labels: keep(prev.labels, d.timestamp),
        avg: keep(prev.avg, parseFloat(d.avgLatency)),
        p95: keep(prev.p95, parseFloat(d.p95Latency)),
        errors: keep(prev.errors, d.errors)
      }));
    };
    const onFinished = (d) => { // test ended without the user pressing STOP
      setIsRunning(false);
      setSummaryData(d.summary);
      setError(FINISH_REASONS[d.reason] || 'Test ended.');
    };
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('status', onStatus);
    socket.on('live-metrics', onMetrics);
    socket.on('test-finished', onFinished);
    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('status', onStatus);
      socket.off('live-metrics', onMetrics);
      socket.off('test-finished', onFinished);
    };
  }, []);

  // Dynamic update: while a test runs, send slider changes to the backend (debounced)
  useEffect(() => {
    if (!isRunning) return;
    const t = setTimeout(() => {
      post('/api/update-params', { virtualUsers, latency: chaosLatency }).catch((e) => setError(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [virtualUsers, chaosLatency, isRunning]);

  const startTest = async () => {
    setError('');
    setSummaryData(null);
    setLive(null);
    setSeries(emptySeries);
    try {
      await post('/api/start-test', { targetUrl, virtualUsers, latency: chaosLatency });
      setIsRunning(true);
    } catch (e) {
      setError(e.message === 'Failed to fetch' ? 'Cannot reach the backend. Is it running on port 4000?' : e.message);
    }
  };

  const stopTest = async () => {
    try {
      const data = await post('/api/stop-test');
      setSummaryData(data.summary);
    } catch (e) {
      setError(e.message);
    }
    setIsRunning(false);
  };

  const chartData = {
    labels: series.labels,
    datasets: [
      { label: 'Avg Latency (ms)', data: series.avg, borderColor: '#0EA5E9', backgroundColor: 'rgba(14, 165, 233, 0.2)', fill: true, tension: 0.3, yAxisID: 'y' },
      { label: 'P95 Latency (ms)', data: series.p95, borderColor: '#A78BFA', tension: 0.3, yAxisID: 'y' },
      { label: 'Errors per tick', data: series.errors, borderColor: '#EF4444', borderDash: [5, 5], tension: 0.3, yAxisID: 'y1' }
    ]
  };

  const chartOptions = {
    animation: false,
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: { grid: { color: '#1e293b' }, ticks: { color: '#64748b' } },
      y: { position: 'left', beginAtZero: true, grid: { color: '#1e293b' }, ticks: { color: '#64748b' }, title: { display: true, text: 'Latency (ms)', color: '#64748b' } },
      y1: { position: 'right', beginAtZero: true, grid: { drawOnChartArea: false }, ticks: { color: '#f87171', precision: 0 }, title: { display: true, text: 'Errors', color: '#f87171' } }
    },
    plugins: { legend: { labels: { color: '#cbd5e1', font: { size: 13 } } } }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans p-4 md:p-10">
      <div className="max-w-[1600px] mx-auto">

        {/* Header */}
        <header className="flex items-center justify-between pb-6 border-b border-slate-800 mb-8">
          <div className="flex items-center gap-4">
            <div className="relative flex items-center justify-center w-14 h-14 rounded-xl bg-slate-900 border border-slate-700 shadow-[0_0_15px_rgba(14,165,233,0.3)]">
              <Activity className="text-cyan-400 w-8 h-8 relative z-10" />
              <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-950 ${isRunning ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,1)] animate-pulse' : 'bg-slate-600'}`}></div>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">SimuNet</h1>
              <p className="text-sm text-slate-400 font-medium mt-1">API Chaos Engineering Dashboard</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-sm font-mono text-slate-400">
              <span className={`w-2 h-2 rounded-full ${connected ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
              {connected ? 'Telemetry: CONNECTED' : 'Telemetry: OFFLINE'}
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-sm font-mono text-slate-400">
              <Server className="w-4 h-4 text-slate-500" />
              {isRunning ? 'Load Engine: ACTIVE' : 'Load Engine: STANDBY'}
            </div>
          </div>
        </header>

        {error && (
          <div className="mb-6 flex items-start justify-between gap-4 rounded-xl border border-red-500/40 bg-red-950/40 px-5 py-3 text-sm text-red-200">
            <span>{error}</span>
            <button onClick={() => setError('')} className="text-red-300 hover:text-white"><XCircle className="w-5 h-5" /></button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 relative">

          {/* Left Panel: Controls */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-xl flex flex-col gap-8">
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800 pb-3">Test Configuration</h2>

            <div>
              <label className="block text-sm font-semibold text-slate-400 mb-3">Target URL</label>
              <input
                type="text"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                disabled={isRunning}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-4 py-3 text-sm font-mono text-cyan-100 focus:border-cyan-500 disabled:opacity-50"
              />
              <p className="text-xs text-slate-500 mt-2">Local targets only (safety default).</p>
            </div>

            <div>
              <div className="flex justify-between mb-3">
                <label className="text-sm font-semibold text-slate-400">Virtual Users (per second)</label>
                <span className="text-sm font-mono text-cyan-400 font-bold">{virtualUsers} VUs</span>
              </div>
              <input
                type="range" min="10" max="1000"
                value={virtualUsers}
                onChange={(e) => setVirtualUsers(Number(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between mb-3">
                <label className="text-sm font-semibold text-slate-400">Chaos Latency</label>
                <span className="text-sm font-mono text-amber-400 font-bold">+{chaosLatency} ms</span>
              </div>
              <input
                type="range" min="0" max="2000" step="50"
                value={chaosLatency}
                onChange={(e) => setChaosLatency(Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="mt-auto pt-4 flex flex-col gap-3">
              {!isRunning ? (
                <button onClick={startTest} className="w-full flex items-center justify-center gap-3 py-4 rounded-xl font-bold text-base bg-gradient-to-r from-emerald-500 to-cyan-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:scale-[1.02] transition-transform">
                  <Play className="w-5 h-5 fill-current" /> Launch Chaos
                </button>
              ) : (
                <button onClick={stopTest} className="w-full flex items-center justify-center gap-3 py-4 rounded-xl font-bold text-base bg-gradient-to-r from-red-600 to-red-500 text-white shadow-[0_0_20px_rgba(239,68,68,0.4)] hover:scale-[1.02] transition-transform animate-pulse">
                  <Square className="w-5 h-5 fill-current" /> STOP TEST
                </button>
              )}
            </div>
          </div>

          {/* Right Panel: live numbers + chart */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-xl flex flex-col">
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800 pb-3 mb-6">Real-Time Telemetry Stream</h2>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <Stat label="Success / tick" value={live ? live.success : '-'} color="text-emerald-400" />
              <Stat label="Errors / tick" value={live ? live.errors : '-'} color="text-red-400" />
              <Stat label="Avg latency" value={live ? live.avgLatency : '-'} unit="ms" color="text-cyan-400" />
              <Stat label="P95 latency" value={live ? live.p95Latency : '-'} unit="ms" color="text-violet-400" />
            </div>

            <div className="flex-1 min-h-[380px] w-full bg-slate-950 p-4 rounded-xl border border-slate-800/50">
              <Line data={chartData} options={chartOptions} />
            </div>
          </div>

          {/* Final report modal */}
          {summaryData && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md">
              <div className="bg-slate-900 border border-cyan-500/50 shadow-[0_0_40px_rgba(14,165,233,0.3)] p-8 rounded-3xl max-w-xl w-full m-4">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-2xl font-bold text-white flex items-center gap-3"><FileText className="text-cyan-400 w-8 h-8" /> Final Report</h3>
                  <button onClick={() => setSummaryData(null)} className="text-slate-400 hover:text-white transition-colors"><XCircle className="w-8 h-8" /></button>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <Stat label="Total requests" value={summaryData.totalRequests} color="text-cyan-400" />
                  <Stat label="Peak RPS" value={summaryData.peakRps} color="text-emerald-400" />
                  <Stat label="Avg latency" value={summaryData.avgLatency} unit="ms" color="text-amber-400" />
                  <Stat label="P95 latency" value={summaryData.p95Latency} unit="ms" color="text-violet-400" />
                  <Stat label="P99 latency" value={summaryData.p99Latency} unit="ms" color="text-violet-400" />
                  <Stat label="Error rate" value={summaryData.errorRate} unit="%" color="text-red-400" />
                  <Stat label="Throughput" value={summaryData.throughput} unit="req/s" color="text-cyan-400" />
                  <Stat label="Duration" value={summaryData.duration} unit="s" color="text-slate-300" />
                </div>
                <p className="text-xs text-slate-500 mb-6">
                  Latency includes the injected chaos delay. Average response time without it: {summaryData.avgResponse} ms.
                  Errors: {summaryData.errorTypes.timeout} timeout, {summaryData.errorTypes.http} HTTP, {summaryData.errorTypes.network} network.
                </p>

                <button onClick={() => setSummaryData(null)} className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold border border-slate-700 transition-colors text-lg">
                  Close Report
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
