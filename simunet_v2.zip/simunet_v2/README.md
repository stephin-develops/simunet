# SimuNet
**API Load Testing and Chaos (Latency) Injection Dashboard** - MCA mini project

SimuNet is a browser-based tool that sends concurrent HTTP GET requests to a test API, lets you inject an
artificial delay, and streams live metrics to a dashboard. It is an educational prototype inspired by the
chaos-engineering idea of Basiri et al., "Chaos Engineering", IEEE Software, 2016.

## Features
- React dashboard: target URL, virtual users (10-1000 per second) and chaos latency (0-2000 ms) sliders
- Node.js **worker thread** generates the load with Axios; the Express main thread stays free
- Live telemetry over **Socket.IO** drawn with Chart.js (avg latency, P95 latency, errors per tick)
- Change virtual users and delay **while the test is running** (applies from the next tick)
- Final report: total requests, peak RPS, throughput, avg / P95 / P99 latency, error rate with error types
- Safety: local targets only by default, input validation, 5 s request timeout, 5-minute automatic stop,
  non-overlapping request batches, worker crash handling, CORS limited to localhost

## Not included (future work)
Redis storage, Docker, multi-node load generation, PDF export, user accounts, persistent history,
failure injection other than latency.

## Tech stack
Frontend: React 19, Vite, Chart.js + react-chartjs-2, lucide-react, Tailwind CSS (loaded from the CDN in `index.html`, so internet is needed)
Backend: Node.js `worker_threads`, Express 5, Socket.IO, Axios, CORS

## Run
Requires Node.js 20 or newer.

```bash
cd backend
npm install
npm start            # http://localhost:4000

cd ../frontend       # in a second terminal
npm install
npm run dev          # open the URL printed by Vite
```

Default target: `http://localhost:4000/api/ping` (answers after 10-40 ms). To test another system you own or have
written permission to test, start the backend with `ALLOW_REMOTE_TARGETS=true`.

## Tests
```bash
cd backend
npm test
```

## API
| Method | Path | Purpose |
|---|---|---|
| POST | `/api/start-test` | `{ targetUrl, virtualUsers, latency }` starts a test |
| POST | `/api/update-params` | `{ virtualUsers, latency }` changes load while running |
| POST | `/api/stop-test` | stops the test and returns the summary |
| GET | `/api/status` | running state and limits |
| GET | `/api/ping` | safe local target |

Socket.IO events: `live-metrics` (every tick), `test-finished` (automatic stop), `status`.

## Metric definitions
- **Latency**: time from the start of a request's chaos delay to its response, in ms (so it includes the injected delay). Successful requests only.
- **Response time**: the same, without the injected delay.
- **Peak RPS**: highest number of completed requests per second in any tick.
- **Error**: a request that timed out, got a non-2xx status, or failed at network level.
- Results depend on the machine, network and target. One run is a demonstration, not a benchmark.
