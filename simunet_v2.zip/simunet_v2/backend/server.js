'use strict';
const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const { Server } = require('socket.io');
const { Worker } = require('worker_threads');
const lib = require('./lib');

const PORT = process.env.PORT || 4000;
const ALLOW_REMOTE = process.env.ALLOW_REMOTE_TARGETS === 'true';
// Only pages served from localhost may call the API (any port, e.g. the Vite dev server).
const ORIGIN = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;

const app = express();
app.use(cors({ origin: ORIGIN }));
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: ORIGIN } });

// One active test at a time (single-user prototype).
let session = null; // { worker, stats, startedAt, config, timer }

function stopSession() {
  if (!session) return null;
  const { worker, stats, startedAt, config, timer } = session;
  clearTimeout(timer);
  session = null;                       // clear first so the worker's 'exit' event is ignored
  worker.terminate().catch(() => {});
  return lib.summarise(stats, startedAt, Date.now(), config);
}

// Ends a test that was not stopped by the user (time limit reached, worker crashed).
function finishAutomatically(reason, errorMessage) {
  const summary = stopSession();
  if (summary) io.emit('test-finished', { reason, error: errorMessage || null, summary });
}

// --- Safe local target for demonstrations: answers after a random 10-40 ms ---
app.get('/api/ping', (req, res) => {
  setTimeout(() => res.json({ status: 'ok' }), Math.random() * 30 + 10);
});

app.get('/api/status', (req, res) => {
  res.json({
    running: !!session,
    config: session ? session.config : null,
    limits: lib.LIMITS,
    remoteTargetsAllowed: ALLOW_REMOTE
  });
});

app.post('/api/start-test', (req, res) => {
  const checked = lib.validateStartConfig(req.body, { allowRemote: ALLOW_REMOTE });
  if (checked.error) return res.status(400).json({ error: checked.error });
  const config = checked.value;

  stopSession(); // only one test at a time

  const worker = new Worker(path.join(__dirname, 'worker.js'), {
    workerData: { ...config, tickMs: lib.LIMITS.TICK_MS, timeoutMs: lib.LIMITS.REQUEST_TIMEOUT_MS }
  });

  session = {
    worker,
    config,
    stats: lib.createStats(),
    startedAt: Date.now(),
    timer: setTimeout(() => finishAutomatically('max-duration'), lib.LIMITS.MAX_DURATION_SEC * 1000)
  };

  worker.on('message', (metrics) => {
    if (!session || session.worker !== worker) return;
    lib.addTick(session.stats, metrics);
    const { latencies, responseSum, ...live } = metrics; // do not send raw samples to the browser
    io.emit('live-metrics', live);
  });

  worker.on('error', (err) => {
    console.error('Worker error:', err.message);
    if (session && session.worker === worker) finishAutomatically('worker-error', err.message);
  });

  worker.on('exit', () => {
    if (session && session.worker === worker) finishAutomatically('worker-exit');
  });

  res.json({ message: 'Stress test initiated', limits: lib.LIMITS });
});

// Change load / delay while the test is running (applies from the next tick).
app.post('/api/update-params', (req, res) => {
  if (!session) return res.status(409).json({ error: 'No test is running' });
  const checked = lib.validateParams(req.body);
  if (checked.error) return res.status(400).json({ error: checked.error });
  Object.assign(session.config, checked.value);
  session.worker.postMessage({ type: 'update', ...checked.value });
  res.json({ message: 'Parameters updated dynamically', ...checked.value });
});

app.post('/api/stop-test', (req, res) => {
  const summary = stopSession();
  if (!summary) return res.status(409).json({ error: 'No test is running' });
  res.json({ summary });
});

// Malformed JSON and other errors -> clean JSON response
app.use((err, req, res, next) => {
  res.status(err.status || 500).json({ error: err.status === 400 ? 'Invalid JSON body' : 'Internal server error' });
});

io.on('connection', (socket) => {
  socket.emit('status', { running: !!session });
});

function shutdown() {
  stopSession();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 500).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

server.listen(PORT, () => console.log(`SimuNet Backend running on port ${PORT}`));
