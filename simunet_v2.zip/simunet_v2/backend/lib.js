'use strict';
// Pure helper functions (no Express / Socket.IO) so they can be unit-tested.

const LIMITS = {
  MIN_VUS: 1,
  MAX_VUS: 1000,
  MAX_LATENCY_MS: 2000,
  MAX_DURATION_SEC: 300,   // a test stops automatically after 5 minutes
  REQUEST_TIMEOUT_MS: 5000, // each request is aborted after 5 seconds
  TICK_MS: 1000,
  MAX_SAMPLES: 200000       // latency samples kept for percentile calculation
};

const LOCAL_HOSTS = new Set(['localhost', '127.0.0.1', '::1', '[::1]']);

function toInt(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.trunc(n) : NaN;
}

/** Validate virtual users + latency. Returns { value } or { error }. */
function validateParams({ virtualUsers, latency } = {}) {
  const vus = toInt(virtualUsers);
  const lat = toInt(latency === undefined || latency === '' ? 0 : latency);
  if (Number.isNaN(vus) || vus < LIMITS.MIN_VUS || vus > LIMITS.MAX_VUS) {
    return { error: `virtualUsers must be a number between ${LIMITS.MIN_VUS} and ${LIMITS.MAX_VUS}` };
  }
  if (Number.isNaN(lat) || lat < 0 || lat > LIMITS.MAX_LATENCY_MS) {
    return { error: `latency must be a number between 0 and ${LIMITS.MAX_LATENCY_MS} ms` };
  }
  return { value: { virtualUsers: vus, latency: lat } };
}

/** Validate a full start request (URL + params). Remote hosts are blocked unless allowRemote is true. */
function validateStartConfig(body = {}, { allowRemote = false } = {}) {
  if (typeof body.targetUrl !== 'string' || body.targetUrl.trim() === '') {
    return { error: 'targetUrl is required' };
  }
  let url;
  try {
    url = new URL(body.targetUrl.trim());
  } catch {
    return { error: 'targetUrl is not a valid URL' };
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    return { error: 'targetUrl must start with http:// or https://' };
  }
  if (!allowRemote && !LOCAL_HOSTS.has(url.hostname)) {
    return {
      error: 'Only local targets (localhost / 127.0.0.1) are allowed. ' +
             'Set ALLOW_REMOTE_TARGETS=true only for systems you own or have written permission to test.'
    };
  }
  const params = validateParams(body);
  if (params.error) return params;
  return { value: { targetUrl: url.toString(), ...params.value } };
}

/** Nearest-rank percentile of an ascending-sorted array. */
function percentile(sorted, p) {
  if (!sorted.length) return 0;
  const rank = Math.ceil((p / 100) * sorted.length);
  return sorted[Math.min(sorted.length, Math.max(1, rank)) - 1];
}

function createStats() {
  return {
    totalReq: 0, totalErrors: 0, successCount: 0,
    latencySum: 0, responseSum: 0, peakRps: 0,
    errorTypes: { timeout: 0, http: 0, network: 0 },
    latencies: [], seen: 0
  };
}

/** Fold one worker tick message into the running statistics. */
function addTick(stats, m) {
  const total = m.success + m.errors;
  stats.totalReq += total;
  stats.totalErrors += m.errors;
  stats.successCount += m.success;
  stats.responseSum += m.responseSum || 0;
  if (m.errorTypes) {
    for (const k of Object.keys(stats.errorTypes)) stats.errorTypes[k] += m.errorTypes[k] || 0;
  }
  // requests completed per second for this tick (cycle can be longer than 1 s if requests are slow)
  const cycleSec = Math.max(m.cycleMs || LIMITS.TICK_MS, 1) / 1000;
  const rps = Math.round(total / cycleSec);
  if (rps > stats.peakRps) stats.peakRps = rps;

  for (const l of m.latencies || []) {
    stats.latencySum += l;
    stats.seen += 1;
    if (stats.latencies.length < LIMITS.MAX_SAMPLES) {
      stats.latencies.push(l);
    } else {
      // reservoir sampling keeps the sample unbiased once the cap is reached
      const j = Math.floor(Math.random() * stats.seen);
      if (j < LIMITS.MAX_SAMPLES) stats.latencies[j] = l;
    }
  }
}

const round2 = (n) => Number(n.toFixed(2));

/** Build the final summary shown in the "Final Report". */
function summarise(stats, startMs, endMs, config) {
  const durationSec = Math.max((endMs - startMs) / 1000, 0.001);
  const sorted = [...stats.latencies].sort((a, b) => a - b);
  return {
    duration: Number(durationSec.toFixed(1)),
    totalRequests: stats.totalReq,
    successfulRequests: stats.successCount,
    errors: stats.totalErrors,
    errorTypes: { ...stats.errorTypes },
    errorRate: stats.totalReq > 0 ? round2((stats.totalErrors / stats.totalReq) * 100) : 0,
    avgLatency: stats.successCount > 0 ? round2(stats.latencySum / stats.successCount) : 0,
    avgResponse: stats.successCount > 0 ? round2(stats.responseSum / stats.successCount) : 0,
    p50Latency: round2(percentile(sorted, 50)),
    p95Latency: round2(percentile(sorted, 95)),
    p99Latency: round2(percentile(sorted, 99)),
    peakRps: stats.peakRps,
    throughput: round2(stats.totalReq / durationSec),
    config
  };
}

module.exports = { LIMITS, validateParams, validateStartConfig, percentile, createStats, addTick, summarise };
