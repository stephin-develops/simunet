'use strict';
// Load-generation worker. Runs in its own thread (worker_threads).
// Every tick it fires `virtualUsers` concurrent HTTP GET requests, optionally
// delaying each by `latency` ms (chaos injection), then reports one metrics message.
// Ticks never overlap: the next batch starts only after the previous one has finished.

const { parentPort, workerData } = require('worker_threads');
const { performance } = require('perf_hooks');
const axios = require('axios');

let { targetUrl, virtualUsers, latency } = workerData;
const tickMs = workerData.tickMs || 1000;
const timeoutMs = workerData.timeoutMs || 5000;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Live slider changes sent by the main thread; they apply from the next tick.
parentPort.on('message', (msg) => {
  if (msg && msg.type === 'update') {
    virtualUsers = msg.virtualUsers;
    latency = msg.latency;
  }
});

function classify(err) {
  if (err && (err.code === 'ECONNABORTED' || err.code === 'ETIMEDOUT')) return 'timeout';
  if (err && err.response) return 'http';   // server answered with a non-2xx status
  return 'network';                         // refused, reset, DNS failure, ...
}

function percentile95(values) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.max(1, Math.ceil(0.95 * sorted.length)) - 1];
}

async function runBatch() {
  const users = virtualUsers;   // read once so the whole batch is consistent
  const delay = latency;
  const latencies = [];         // end-to-end time per successful request (includes injected delay)
  let responseSum = 0;          // time spent waiting for the target only (excludes injected delay)
  let errors = 0;
  const errorTypes = { timeout: 0, http: 0, network: 0 };

  await Promise.all(
    Array.from({ length: users }, async () => {
      const start = performance.now();
      try {
        if (delay > 0) await sleep(delay);
        const afterDelay = performance.now();
        await axios.get(targetUrl, { timeout: timeoutMs });
        const end = performance.now();
        latencies.push(end - start);
        responseSum += end - afterDelay;
      } catch (err) {
        errors++;
        errorTypes[classify(err)]++;
      }
    })
  );
  return { latencies, responseSum, errors, errorTypes };
}

async function loop() {
  for (;;) {
    const tickStart = performance.now();
    const { latencies, responseSum, errors, errorTypes } = await runBatch();
    const batchMs = performance.now() - tickStart;
    const success = latencies.length;
    const avg = success ? latencies.reduce((a, b) => a + b, 0) / success : 0;

    parentPort.postMessage({
      timestamp: new Date().toLocaleTimeString(),
      success,
      errors,
      avgLatency: avg.toFixed(2),
      p95Latency: percentile95(latencies).toFixed(2),
      avgResponse: (success ? responseSum / success : 0).toFixed(2),
      cycleMs: Math.max(tickMs, batchMs),
      responseSum,
      errorTypes,
      latencies
    });

    await sleep(Math.max(0, tickMs - batchMs)); // wait out the rest of the tick
  }
}

// An unexpected error here surfaces as the worker's 'error' event on the main thread.
loop();
