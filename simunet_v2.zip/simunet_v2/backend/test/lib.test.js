const test = require('node:test');
const assert = require('node:assert');
const lib = require('../lib');

test('valid local config is accepted', () => {
  const r = lib.validateStartConfig({ targetUrl: 'http://localhost:4000/api/ping', virtualUsers: 50, latency: 0 });
  assert.ok(r.value);
  assert.strictEqual(r.value.virtualUsers, 50);
});

test('missing, malformed and non-http URLs are rejected', () => {
  assert.ok(lib.validateStartConfig({ virtualUsers: 10, latency: 0 }).error);
  assert.ok(lib.validateStartConfig({ targetUrl: 'not a url', virtualUsers: 10, latency: 0 }).error);
  assert.ok(lib.validateStartConfig({ targetUrl: 'ftp://localhost/x', virtualUsers: 10, latency: 0 }).error);
});

test('remote targets are blocked unless explicitly allowed', () => {
  const body = { targetUrl: 'https://example.com', virtualUsers: 10, latency: 0 };
  assert.ok(lib.validateStartConfig(body).error);
  assert.ok(lib.validateStartConfig(body, { allowRemote: true }).value);
});

test('virtual users and latency are range-checked', () => {
  assert.ok(lib.validateParams({ virtualUsers: 0, latency: 0 }).error);
  assert.ok(lib.validateParams({ virtualUsers: 1001, latency: 0 }).error);
  assert.ok(lib.validateParams({ virtualUsers: 10, latency: -1 }).error);
  assert.ok(lib.validateParams({ virtualUsers: 10, latency: 2001 }).error);
  assert.ok(lib.validateParams({ virtualUsers: 'abc', latency: 0 }).error);
  assert.ok(lib.validateParams({ virtualUsers: 1000, latency: 2000 }).value);
});

test('percentile uses nearest rank', () => {
  const data = Array.from({ length: 100 }, (_, i) => i + 1);
  assert.strictEqual(lib.percentile(data, 50), 50);
  assert.strictEqual(lib.percentile(data, 95), 95);
  assert.strictEqual(lib.percentile(data, 99), 99);
  assert.strictEqual(lib.percentile([], 95), 0);
});

test('summary matches known input', () => {
  const stats = lib.createStats();
  lib.addTick(stats, { success: 3, errors: 1, latencies: [100, 200, 300], responseSum: 150, cycleMs: 1000, errorTypes: { timeout: 1, http: 0, network: 0 } });
  lib.addTick(stats, { success: 2, errors: 0, latencies: [400, 500], responseSum: 100, cycleMs: 1000 });
  const s = lib.summarise(stats, 0, 10000, { virtualUsers: 4 });
  assert.strictEqual(s.totalRequests, 6);
  assert.strictEqual(s.errors, 1);
  assert.strictEqual(s.errorRate, 16.67);
  assert.strictEqual(s.avgLatency, 300);       // (100+200+300+400+500)/5
  assert.strictEqual(s.avgResponse, 50);       // 250/5
  assert.strictEqual(s.p95Latency, 500);
  assert.strictEqual(s.peakRps, 4);
  assert.strictEqual(s.throughput, 0.6);       // 6 requests / 10 s
  assert.strictEqual(s.errorTypes.timeout, 1);
});

test('peak RPS accounts for slow cycles', () => {
  const stats = lib.createStats();
  lib.addTick(stats, { success: 100, errors: 0, latencies: [], cycleMs: 2000 });
  assert.strictEqual(stats.peakRps, 50);
});

test('empty run gives zeros, not NaN', () => {
  const s = lib.summarise(lib.createStats(), 0, 1000, {});
  assert.strictEqual(s.errorRate, 0);
  assert.strictEqual(s.avgLatency, 0);
});
