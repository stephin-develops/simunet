// Integration test for the load worker against a throw-away local HTTP server.
const test = require('node:test');
const assert = require('node:assert');
const http = require('http');
const path = require('path');
const { Worker } = require('worker_threads');

function startTarget(handler) {
  return new Promise((resolve) => {
    const srv = http.createServer(handler);
    srv.listen(0, '127.0.0.1', () => resolve(srv));
  });
}

function collect(workerData, ms) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(path.join(__dirname, '..', 'worker.js'), { workerData });
    const messages = [];
    worker.on('message', (m) => messages.push({ ...m, receivedAt: Date.now() }));
    worker.on('error', reject);
    setTimeout(async () => { await worker.terminate(); resolve(messages); }, ms);
  });
}

test('counts successes and measures latency including injected delay', async () => {
  const srv = await startTarget((req, res) => setTimeout(() => res.end('ok'), 20));
  const url = `http://127.0.0.1:${srv.address().port}/`;
  const msgs = await collect({ targetUrl: url, virtualUsers: 10, latency: 100, tickMs: 300, timeoutMs: 2000 }, 1500);
  srv.close();
  assert.ok(msgs.length >= 2);
  assert.strictEqual(msgs[0].success, 10);
  assert.strictEqual(msgs[0].errors, 0);
  assert.ok(Number(msgs[0].avgLatency) >= 115, 'latency should include the 100 ms injected delay');
  assert.ok(Number(msgs[0].avgResponse) < Number(msgs[0].avgLatency));
});

test('batches never overlap when the target is slow', async () => {
  const srv = await startTarget((req, res) => setTimeout(() => res.end('ok'), 600));
  const url = `http://127.0.0.1:${srv.address().port}/`;
  const msgs = await collect({ targetUrl: url, virtualUsers: 5, latency: 0, tickMs: 200, timeoutMs: 3000 }, 2500);
  srv.close();
  assert.ok(msgs.length >= 2);
  for (let i = 1; i < msgs.length; i++) {
    assert.ok(msgs[i].receivedAt - msgs[i - 1].receivedAt >= 500, 'next batch must wait for the previous one');
  }
  assert.ok(msgs[0].cycleMs >= 600);
});

test('HTTP errors and timeouts are classified', async () => {
  const bad = await startTarget((req, res) => { res.statusCode = 500; res.end('x'); });
  const hung = await startTarget(() => {}); // never answers
  const m1 = await collect({ targetUrl: `http://127.0.0.1:${bad.address().port}/`, virtualUsers: 4, latency: 0, tickMs: 200, timeoutMs: 1000 }, 700);
  const m2 = await collect({ targetUrl: `http://127.0.0.1:${hung.address().port}/`, virtualUsers: 4, latency: 0, tickMs: 200, timeoutMs: 300 }, 1200);
  bad.close(); hung.close();
  assert.strictEqual(m1[0].errorTypes.http, 4);
  assert.strictEqual(m2[0].errorTypes.timeout, 4);
});

test('unreachable target counts as network errors and the worker keeps running', async () => {
  const msgs = await collect({ targetUrl: 'http://127.0.0.1:1/', virtualUsers: 3, latency: 0, tickMs: 200, timeoutMs: 1000 }, 900);
  assert.ok(msgs.length >= 2);
  assert.strictEqual(msgs[0].errors, 3);
  assert.strictEqual(msgs[0].errorTypes.network, 3);
});

test('live update changes the number of virtual users from the next tick', async () => {
  const srv = await startTarget((req, res) => res.end('ok'));
  const url = `http://127.0.0.1:${srv.address().port}/`;
  const worker = new Worker(path.join(__dirname, '..', 'worker.js'), { workerData: { targetUrl: url, virtualUsers: 2, latency: 0, tickMs: 200, timeoutMs: 1000 } });
  const counts = [];
  worker.on('message', (m) => counts.push(m.success));
  setTimeout(() => worker.postMessage({ type: 'update', virtualUsers: 7, latency: 0 }), 450);
  await new Promise((r) => setTimeout(r, 1300));
  await worker.terminate(); srv.close();
  assert.strictEqual(counts[0], 2);
  assert.strictEqual(counts[counts.length - 1], 7);
});
